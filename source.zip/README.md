# AI-Cloud-Quality-Scanner-Pipeline

1. Start Dev Container
2. Run poetry env use python3.12
3. Run source $(poetry env info --path)/bin/activate
4. Run poetry install